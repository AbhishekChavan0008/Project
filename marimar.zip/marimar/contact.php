<!-- Contact -->
<h1>Contact Us</h1>
  <div class="contact">
    <div class="contact_container">
      <div class="container">
        <div class="row">
          <div class="col">
            <div class="section_title text-center">
              <div>Ciao</div>
              <h1>Say Hello</h1>
            </div>
            <div class="contact_text text-center">
              <p>Maecenas sollicitudin tincidunt maximus. Morbi tempus malesuada erat sed pellentesque. Donec pharetra mattis nulla, id laoreet neque scelerisque at. Quisque eget sem non ligula consectetur ultrices in quis augue. Donec imperd iet leo eget tortor dictum, eget varius eros sagittis.</p>
            </div>
            <div class="contact_form_container">
            <form>
                    
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-6 ps-0 mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="name" class="form-control shadow-none">
                                </div>
                                <div class="col-md-6 ps-0 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control shadow-none">
                                </div>
                                <div class="col-md-6 ps-0 mb-3">
                                    <label class="form-label">phone</label>
                                    <input type="number" class="form-control shadow-none">
                                </div>

                                <div class="col-md-6 ps-0 mb-3">
                                    <label class="form-label">subject</label>
                                    <input type="number" class="form-control shadow-none">
                                </div>
                                
                                <div class="col-md-6 ps-0 mb-3">
                                    <label class="form-label">Message</label>
                                    <textarea class="form-control showdow-none" rows="1"></textarea>
                                </div>
                                <div class="col-md-6 ps-0 mb-3">
                                    <label class="form-label">Pincode</label>
                                    <input type="number" class="form-control shadow-none">
                                </div>
                                
                               
                            </div>
                        </div>
                        <div class="text-center my-1">
                            <button type="submit" class="btn btn-dark shadow-none">Submit</button>
                        </div>


                    </div>
                </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Map -->
    <div class="contact_map_container">
      <div class="map">
        <div id="google_map" class="google_map">
          <div class="map_container">
            <div id="map"></div>
          </div>
        </div>
      </div>

      <!-- Contact Map Content -->
      <div class="contact_map_content">
        <div class="d-flex flex-column align-items-center justify-content-center">
          
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
